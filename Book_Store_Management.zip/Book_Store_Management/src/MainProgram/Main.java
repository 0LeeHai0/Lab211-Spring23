package MainProgram;

import Management.newFunction;

public class Main {

    public static void main(String[] args) {
        newFunction funct = new newFunction();
        funct.menuMain();
    }
}
