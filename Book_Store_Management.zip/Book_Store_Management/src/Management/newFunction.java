
package Management;

public class newFunction {
    Management man = new Management();
    public int menuMain() {
        int choice;
        System.out.println("+----------------------------------+");
        System.out.println("|       BOOK STORE MANAGEMENT      |");
        System.out.println("+----------------------------------+");
        System.out.format("|%-34s|\n", "Choose funct:");
        System.out.format("|%-34s|\n", "1.Publishers management");
        System.out.format("|%-34s|\n", "2.Books management:");
        System.out.format("|%-34s|\n", "3.Exit program!");
        System.out.println("+----------------------------------+");
        System.out.println("|   REMEMBER TO SAVE BEDORE EXIT   |");
        System.out.println("+----------------------------------+");

        while (true) {
            man.readFromPubFile();
            man.readFromBookFile();
            choice = Validation.getInt(1, 3);
            switch (choice) {
                case 1:
                    publisherMenu();
                    return 0;
                case 2:
                    bookMenu();
                    return 0;
                case 3:
                    System.out.println("+----------------------+");
                    System.out.println("| Thank you for using! |");
                    System.out.println("+----------------------+");
                    return 0;
            }
        }
    }

    private int publisherMenu() {
        int choice;
        System.out.println("PUBLISHERS MANAGEMENT");
        System.out.println("+--------------------------------------------+");
        System.out.format("|%-44s|\n", "1.1. Create a Publisher");
        System.out.format("|%-44s|\n", "1.2. Delete the Publisher");
        System.out.format("|%-44s|\n", "1.3. Save the Publishers list to file");
        System.out.format("|%-44s|\n", "1.4. Print the Publisher lisy from the file.");
        System.out.println("+--------------------------------------------+");
        System.out.println("|      REMEMBER TO SAVE BEFORE GO BACK       |");
        System.out.println("|       Press 0 to go back main menu!        |");
        System.out.println("+--------------------------------------------+");

        while (true) {
            choice = Validation.getInt(0, 4);
            switch (choice) {
                case 1:
                    man.createPublisher();
                    if (Validation.getYN() == true) {
                        return publisherMenu();
                    } else {
                        return menuMain();
                    }
                case 2:
                    man.deletePublisher();
                    return publisherMenu();
                case 3:
                    man.saveToPubFile();
                    if (Validation.getYN() == true) {
                        return publisherMenu();
                    } else {
                        return menuMain();
                    }
                case 4:
                    man.layoutForPublisher();
                    if (Validation.getYN() == true) {
                        return publisherMenu();
                    } else {
                        return menuMain();
                    }
                case 0:
                    return menuMain();

            }
        }
    }

    private int bookMenu() {
        int choice;
        System.out.println("BOOKS MANAGEMENT");
        System.out.println("+--------------------------------------------+");
        System.out.format("|%-44s|\n", "2.1. Create a Book");
        System.out.format("|%-44s|\n", "2.2. Search the Book");
        System.out.format("|%-44s|\n", "2.3. Update a Book");
        System.out.format("|%-44s|\n", "2.4. Delete the Book");
        System.out.format("|%-44s|\n", "2.5. Save the Books list to file.");
        System.out.format("|%-44s|\n", "2.6. Print the Books list from the file.");
        System.out.println("+--------------------------------------------+");
        System.out.println("|      REMEMBER TO SAVE BEFORE GO BACK       |");
        System.out.println("|       Press 0 to go back main menu!        |");
        System.out.println("+--------------------------------------------+");

        while (true) {
            choice = Validation.getInt(0, 6);
            switch (choice) {
                case 1:
                    man.createBook();
                    if (Validation.getYN() == true) {
                        return bookMenu();
                    } else {
                        return menuMain();
                    }
                case 2:
                    man.sreachTheBook();
                    return bookMenu();
                case 3:
                    man.updateBook();
                    return bookMenu();
                case 4:
                    man.deleteBook();
                    return bookMenu();
                case 5:
                    man.saveToBookFile();
                    if (Validation.getYN() == true) {
                        return bookMenu();
                    } else {
                        return menuMain();
                    }
                case 6:
                    man.layoutForBook();
                    if (Validation.getYN() == true) {
                        return bookMenu();
                    } else {
                        return menuMain();
                    }
                case 0:
                    return menuMain();
            }
        }
    }
    
}
