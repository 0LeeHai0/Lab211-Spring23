package Management;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import obj.Books;
import obj.Publishers;

public class Management {

    ArrayList<Publishers> pubList = new ArrayList<Publishers>();
    ArrayList<Books> bookList = new ArrayList<Books>();
    
    void createPublisher() {
        pubList.add(inputPub());
        System.out.println("Created!");
    }

    boolean findBookPublisherID(String ID) {
        for (int i = 0; i < bookList.size(); i++) {
            if (bookList.get(i).getPublisherID().equals(ID)) {
                return true;
            }
        }
        return false;
    }

    Publishers inputPub() {
        Publishers obj = new Publishers();

        System.out.println("Publisher's ID(Pxxxxx): ");
        obj.setpublisherID(Validation.getWithRegex("[P,p][0-9]{5}").toUpperCase());
        while (findPubID(obj.getpublisherID()) > -1) {
            System.err.println("Duplicate ID");
            obj.setpublisherID(Validation.getWithRegex("[P,p][0-9]{5}").toUpperCase());
        }

        System.out.println("Publisher's name: ");
        obj.setPublisherName(Validation.getWithRegex("[A-Z,a-z,0-9, ]{5,30}"));

        System.out.println("Phone number: ");
        obj.setPhoneNum(Validation.getWithRegex("[0-9]{10,12}"));

        return obj;
    }

    void deletePublisher() {
        System.out.println("Enter Publisher's ID to remove:");
        String ID = Validation.getWithRegex("[P,p][0-9]{5}").toUpperCase();
        int target = findPubID(ID);
        if (target > -1 && findBookPublisherID(ID) == false) {
            System.out.println("The Publisher will be deleted!");
            if (Validation.getYN() == true) {
                pubList.remove(target);
                System.out.println("Publisher was deleted.");
            } else {
                System.err.println("Publisher was not deleted.");
            }

        } else if (target == -1) {
            System.err.println("Publisher’s ID does not exist!");
        } else {
            System.err.println("Publisher’s ID can not delete");
        }
    }

    void saveToPubFile() {
        try {
            File f = new File(".\\src\\Data\\publisher.dat");
            FileWriter fw = new FileWriter(f);
            BufferedWriter bw = new BufferedWriter(fw);
            for (Publishers p : pubList) {
                bw.write(p.toString());
            }
            System.out.println("Saved!");
            bw.close();
            fw.close();
        } catch (Exception e) {
            System.err.println("Can't save file.");
        }
    }

    void readFromPubFile() {
        if (pubList.isEmpty()) {
            try {
                File f = new File(".\\src\\Data\\publisher.dat");
                if (!f.exists()) {
                    return;
                }
                FileReader fr = new FileReader(f);
                BufferedReader br = new BufferedReader(fr);
                while (true) {
                    String line = br.readLine();
                    if (line == null) {
                        break;
                    }
                    String info[] = line.split("[|]");
                    String ID = info[1].trim();
                    String Name = info[2].trim();
                    String Phone = info[3].trim();
                    if (!(ID.isEmpty())) {
                        pubList.add(new Publishers(ID, Name, Phone));
                    }
                }
                br.close();
                fr.close();
            } catch (Exception e) {
                System.out.println("Error input file.");
            }
        }
    }

    void printFromPubFile() {
        ArrayList<Publishers> newList = new ArrayList<Publishers>();
        try {
            File f = new File(".\\src\\Data\\publisher.dat");
            if (!f.exists()) {
                throw new Exception();
            }
            FileReader fr = new FileReader(f);
            BufferedReader br = new BufferedReader(fr);
            while (true) {
                String line = br.readLine();
                if (line == null) {
                    break;
                }
                String info[] = line.split("[|]");
                String ID = info[1].trim();
                String Name = info[2].trim();
                String Phone = info[3].trim();
                if (!(ID.isEmpty())) {
                    newList.add(new Publishers(ID, Name, Phone));
                }
            }
            br.close();
            fr.close();
        } catch (Exception e) {
            System.err.println("Error input file.");
        }
        if (pubList.isEmpty()) {
            System.err.println("Nothing to display!");
        } else {
            Collections.sort(newList, Comparator.comparing(Publishers::getPublisherName));
            for (Publishers p : newList) {
                System.out.print(p);
            }
            newList.clear();
        }
    }

    void layoutForPublisher() {
        System.out.print("PUBLISHER\n");
        System.out.print("+---------+-----------------+------------------+\n");
        System.out.format("| %-8s| %-16s| %-16s |\n", "ID", "NAME", "PHONE");
        System.out.print("+---------+-----------------+------------------+\n");
        printFromPubFile();
        System.out.print("+---------+-----------------+------------------+\n");
    }
//------------------------
    void createBook() {
        if (pubList.isEmpty()) {
            System.out.println();
            System.err.println("There is no publisher in list!");
        } else {
            bookList.add(inputBook());
            System.out.println("Created!");
        }
    }

    int findBookID(String ID) {
        for (int i = 0; i < bookList.size(); i++) {
            if (bookList.get(i).getBookID().equals(ID)) {
                return i;
            }
        }
        return -1;
    }

    int findPubID(String ID) {
        for (int i = 0; i < pubList.size(); i++) {
            if (pubList.get(i).getpublisherID().equals(ID)) {
                return i;
            }
        }
        return -1;
    }

    boolean findBookName(String name) {
       for (int i = 0; i < bookList.size(); i++) {
            if (bookList.get(i).getBookName().toLowerCase().contains(name.toLowerCase())) {
                return true;
            }
        }
        return false;
    }
    
    public void findAndPrintBookName(String name){
        if (bookList.isEmpty() || findBookName(name)==false) {
            System.err.println("Have no any Book!");
        } else {
            for (int i = 0; i < bookList.size(); i++) {
                if (bookList.get(i).getBookName().toLowerCase().contains(name.toLowerCase())) {
                    System.out.println("BOOK DATA:");
                    printFromList(i);
                }
            }
        }
    }

    Books inputBook() {
        Books obj = new Books();
        System.out.println("Publisher's ID(Pxxxxx): ");
        obj.setPublisherID(Validation.getWithRegex("[P,p][0-9]{5}").toUpperCase());
        findBookID(obj.getPublisherID());
        while (findPubID(obj.getPublisherID()) == -1) {
            System.err.println("Publisher’s Id is not found");
            obj.setPublisherID(Validation.getWithRegex("[P,p][0-9]{5}").toUpperCase());
        }

        System.out.println("Book's ID(Bxxxxx): ");
        obj.setBookID(Validation.getWithRegex("[B,b][0-9]{5}").toUpperCase());
        while (findBookID(obj.getBookID()) > -1) {
            System.err.println("Duplicate ID");
            obj.setBookID(Validation.getWithRegex("[B,b][0-9]{5}").toUpperCase());
        }

        System.out.println("Book's name: ");
        obj.setBookName(Validation.getWithRegex("[A-Z,a-z,0-9, ]{5,30}"));

        System.out.println("Book's price: ");
        obj.setBookPrice(Validation.getReal(0));

        System.out.println("Book's quantity: ");
        obj.setQuantity(Validation.getInt(1, Integer.MAX_VALUE));

        System.out.println("Status(A/NA): ");
        obj.setStatus(Validation.getStatus());

        return obj;
    }

    Books inputToUpdateBook(String bookID) {
        Books obj = new Books();
        try {
            System.out.println("Publisher's ID(Pxxxxx): ");
            obj.setPublisherID(Validation.getWithRegex("[P,p][0-9]{5}||[ ]").toUpperCase());
            if (obj.getPublisherID().isEmpty()) {
                throw new Exception();
            }
            findBookID(obj.getPublisherID());
            while (findPubID(obj.getPublisherID()) == -1) {
                System.err.println("Publisher’s Id is not found");
                obj.setPublisherID(Validation.getWithRegex("[P,p][0-9]{5}||[ ]").toUpperCase());
            }

            obj.setBookID(bookID);

            System.out.println("Book's name: ");
            obj.setBookName(Validation.getWithRegex("[A-Z,a-z,0-9, ]{5,30}"));

            System.out.println("Book's price: ");
            obj.setBookPrice(Validation.getReal(0));

            System.out.println("Book's quantity: ");
            obj.setQuantity(Validation.getInt(1, Integer.MAX_VALUE));

            System.out.println("Status(A/NA): ");
            obj.setStatus(Validation.getStatus());

            return obj;

        } catch (Exception e) {
            return obj = null;
        }
    }

    void printFromList(int index) {
        if (bookList.isEmpty() || index == -1) {
            System.err.println("Have no any Book!");
        } else {
            System.out.print("+----------------+------------------+------------------+----------------+------------------+------------------+----------------+\n");
            System.out.print(bookList.get(index));
            System.out.print("+----------------+------------------+------------------+----------------+------------------+------------------+----------------+\n");

        }
    }

    void findAndPrintPubID(String ID) {
        if (bookList.isEmpty() || findBookPublisherID(ID)==false) {
            System.err.println("Have no any Book!");
        } else {
            for (int i = 0; i < bookList.size(); i++) {
                if (bookList.get(i).getPublisherID().equals(ID)) {
                    System.out.println("BOOK DATA:");
                    printFromList(i);
                }
            }
        }

    }

    int sreachTheBook() {
        int choice;
        System.out.println("+----------------------------------+");
        System.out.format("|%-34s|\n", "1.Enter Book's Name:");
        System.out.format("|%-34s|\n", "2.Enter Publisher’s Id:");
        System.out.format("|%-34s|\n", "3.Go back");
        System.out.println("+----------------------------------+");

        while (true) {
            choice = Validation.getInt(1, 3);
            switch (choice) {
                case 1:
                    System.out.println("Enter Book's Name: ");
                    findAndPrintBookName(Validation.getWithRegex("[A-Z,a-z,0-9, ]{5,30}"));
                    if (Validation.getYN() == true) {
                        return sreachTheBook();
                    } else {
                        return 0;
                    }
                case 2:
                    System.out.println("Enter Publisher's ID: ");
                    findAndPrintPubID(Validation.getWithRegex("[P,p][0-9]{5}").toUpperCase());
                    if (Validation.getYN() == true) {
                        return sreachTheBook();
                    } else {
                        return 0;
                    }
                case 3:
                    return 0;
            }
        }
    }

    void readFromBookFile() {
        if (bookList.isEmpty()) {
            try {
                File f = new File(".\\src\\Data\\book.dat");
                if (!f.exists()) {
                    return;
                }
                FileReader fr = new FileReader(f);
                BufferedReader br = new BufferedReader(fr);
                while (true) {
                    String line = br.readLine();
                    if (line == null) {
                        break;
                    }
                    String info[] = line.split("[|]");
                    String bookID = info[1].trim();
                    String bookName = info[2].trim();
                    double bookPrice = Double.parseDouble(info[3]);
                    int quantity = Integer.valueOf(info[4].trim());
                    double subTotal = Double.parseDouble(info[5]);
                    String pubName = info[6].trim();
                    String status = info[7].trim();
                    if (!(bookID.isEmpty())) {
                        bookList.add(new Books(bookID, bookName, bookPrice, quantity, subTotal, pubName, status));
                    }
                }
                br.close();
                fr.close();
            } catch (Exception e) {
                System.out.println("Error input file.");
            }
        }
    }

    void saveToBookFile() {
        try {
            File f = new File(".\\src\\Data\\book.dat");
            FileWriter fw = new FileWriter(f);
            BufferedWriter bw = new BufferedWriter(fw);
            for (Books p : bookList) {
                bw.write(p.toString());
            }
            System.out.println("Saved!");
            bw.close();
            fw.close();
        } catch (Exception e) {
            System.err.println("Can't save file.");
        }
    }

    void printFromBookFile() {
        ArrayList<Books> newList = new ArrayList<Books>();
        try {
            File f = new File(".\\src\\Data\\book.dat");
            if (!f.exists()) {
                throw new Exception();
            }
            FileReader fr = new FileReader(f);
            BufferedReader br = new BufferedReader(fr);
            while (true) {
                String line = br.readLine();
                if (line == null) {
                    break;
                }
                String info[] = line.split("[|]");
                String bookID = info[1].trim();
                String bookName = info[2].trim();
                double bookPrice = Double.parseDouble(info[3]);
                int quantity = Integer.valueOf(info[4].trim());
                double subTotal = Double.parseDouble(info[5]);
                String pubName = info[6].trim();
                String status = info[7].trim();
                if (!(bookID.isEmpty())) {
                    newList.add(new Books(bookID, bookName, bookPrice, quantity, subTotal, pubName, status));
                }
            }
            br.close();
            fr.close();
        } catch (Exception e) {
            System.err.println("Error input file.");
            return;
        }
        if (newList.isEmpty()) {
            System.err.println("Nothing to display!");
        } else {
            Collections.sort(newList, Comparator.comparingInt(Books::getQuantity).reversed());
            for (Books p : newList) {
                System.out.print(p);
            }
            newList.clear();
        }
    }

    public void updateBook() {
        System.out.println("Enter Book's ID to update:");
        String ID = Validation.getWithRegex("[B,b][0-9]{5}").toUpperCase();
        int target = findBookID(ID);
        if (target > -1) {
            Books input = inputToUpdateBook(ID);
            if (input == null) {
                System.err.println("Updated fail");
            } else {
                System.out.println("The Book will be update!");
                if (Validation.getYN() == true) {
                    bookList.set(target, input);
                    System.out.println("Updated success!");
                } else {
                    System.err.println("Updated fail!");
                }
            }
        } else {
            System.err.println("Book’s Name does not exist");
        }
    }

    void deleteBook() {
        System.out.println("Enter the Book’s ID: ");
        String ID = Validation.getWithRegex("[B,b][0-9]{5}").toUpperCase();
        int target = findBookID(ID);
        if (target > -1) {
            System.out.println("The Book will be delete!");
            if (Validation.getYN() == true) {
                bookList.remove(target);
                System.out.println("Book was deleted.");
            } else {
                System.err.println("The Book was not deleted.");
            }
        } else {
            System.err.println("Book’s Name does not exist!");
        }
    }

    void layoutForBook() {
        System.out.print("BOOK\n");
        System.out.print("+----------------+------------------+------------------+----------------+------------------+------------------+----------------+\n");
        System.out.format("| %-14s | %-16s | %-16s | %-14s | %-16s | %-16s | %-14s |\n", "Book's ID", "Book's Name", "Price", "Quantity", "Subtotal", "Publisher's ID", "Status");
        System.out.print("+----------------+------------------+------------------+----------------+------------------+------------------+----------------+\n");
        printFromBookFile();
        System.out.print("+----------------+------------------+------------------+----------------+------------------+------------------+----------------+\n");
    }

}